## Important info
the node modules was taking up too much space therefore we removed it.
You will have to go through npm install to install the node modules required

## Prerequisites
node v10.15.3 link: https://nodejs.org/en/ This comes with npm

## Steps

```
run npm install within the v.0.0 folder
run npm install within the react folder
```

within v.0.0 use the command npm run dev to run the app

## npm run dev

This runs the nodejs and react project using concurruntly
