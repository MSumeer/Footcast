import React, { Component } from "react";
import "../../Styles/StadiumInfo.css";
class StadiumInfo extends Component {
  render() {
    return (
      <div className="st-container b-radius padding-10 m-left-right">
        <h1>Emirates Stadium</h1>
      </div>
    );
  }
}

export default StadiumInfo;
