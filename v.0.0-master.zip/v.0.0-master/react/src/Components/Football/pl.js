import React, { Component } from "react";

class pl extends Component {
  render() {
    return (
      <div className="title">
        <h1>Premier League</h1>
      </div>
    );
  }
}

export default pl;
